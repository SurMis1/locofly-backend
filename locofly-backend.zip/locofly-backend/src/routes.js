const express = require('express');
const db = require('./db');
const router = express.Router();

// Helper for safe integer conversion
function toInt(val) {
  const n = Number.parseInt(val, 10);
  return Number.isNaN(n) ? null : n;
}

/* ======================================================
   1️⃣ CREATE LOCATION (manual)
   POST /locations { name }
====================================================== */
router.post('/locations', async (req, res, next) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: "name is required" });

    const q = await db.query(
      `INSERT INTO locations (name) VALUES ($1) RETURNING *`,
      [name]
    );

    res.json(q.rows[0]);
  } catch (err) {
    next(err);
  }
});

/* ======================================================
   2️⃣ LIST LOCATIONS
   GET /locations
   (Old behavior preserved if table doesn't exist)
====================================================== */
router.get('/locations', async (req, res, next) => {
  try {
    let result;

    // Preferred: real locations table
    try {
      result = await db.query(`SELECT id, name FROM locations ORDER BY id`);
      if (result.rows.length > 0) return res.json(result.rows);
    } catch (err) {
      // fallback to old behavior
    }

    // Legacy fallback (auto-generated from inventory)
    result = await db.query(`
      SELECT DISTINCT location_id AS id,
             'Location ' || location_id AS name
        FROM inventory
       ORDER BY id
    `);

    res.json(result.rows);

  } catch (err) {
    next(err);
  }
});

/* ======================================================
   3️⃣ ADD ITEM
   POST /items  { item_name, quantity, barcode, location_id }
====================================================== */
router.post('/items', async (req, res, next) => {
  try {
    const { item_name, quantity, barcode, location_id } = req.body;

    if (!item_name || !location_id)
      return res.status(400).json({ error: "item_name and location_id required" });

    const q = await db.query(
      `INSERT INTO inventory (item_name, quantity, location_id, barcode, updated_at)
       VALUES ($1, $2, $3, $4, NOW())
       RETURNING *`,
      [item_name, quantity || 0, location_id, barcode || null]
    );

    res.json(q.rows[0]);
  } catch (err) {
    next(err);
  }
});

/* ======================================================
   4️⃣ EDIT ITEM
   PUT /items/:id   { item_name?, barcode? }
====================================================== */
router.put('/items/:id', async (req, res, next) => {
  try {
    const id = toInt(req.params.id);
    const { item_name, barcode } = req.body;

    const q = await db.query(
      `UPDATE inventory
          SET item_name = COALESCE($1, item_name),
              barcode   = COALESCE($2, barcode),
              updated_at = NOW()
        WHERE id = $3
        RETURNING *`,
      [item_name, barcode, id]
    );

    if (q.rows.length === 0)
      return res.status(404).json({ error: "item not found" });

    res.json(q.rows[0]);

  } catch (err) {
    next(err);
  }
});

/* ======================================================
   5️⃣ GET INVENTORY (location-level, with search)
   GET /inventory?location_id=1&query=milk
====================================================== */
router.get('/inventory', async (req, res, next) => {
  try {
    const locationId = toInt(req.query.location_id);
    const search = (req.query.query || '').trim();

    if (!locationId) {
      return res.status(400).json({ error: 'location_id is required' });
    }

    const params = [locationId];
    let sql = `
      SELECT id, item_name, quantity, location_id, updated_at, barcode
      FROM inventory
      WHERE location_id = $1
    `;

    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      params.push(search);
      sql += `
        AND (
          LOWER(item_name) LIKE $2
          OR barcode = $3
        )
      `;
    }

    sql += ' ORDER BY item_name ASC';

    const result = await db.query(sql, params);
    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

/* ======================================================
   6️⃣ BATCH ADJUST (existing logic untouched)
   POST /inventory/adjust
====================================================== */
router.post('/inventory/adjust', async (req, res, next) => {
  const client = await db.pool.connect();
  try {
    const { location_id, items } = req.body || {};
    const locationId = toInt(location_id);

    if (!locationId || !Array.isArray(items) || items.length === 0) {
      client.release();
      return res.status(400).json({ error: 'location_id and items[] are required' });
    }

    await client.query('BEGIN');
    const updated = [];

    for (const item of items) {
      const id = toInt(item.id);
      const delta = Number(item.delta || 0);
      if (!id || !delta) continue;

      const updateSql = `
        UPDATE inventory
        SET quantity = quantity + $1,
            updated_at = NOW()
        WHERE id = $2 AND location_id = $3
        RETURNING id, item_name, quantity, location_id, updated_at, barcode
      `;
      const result = await client.query(updateSql, [delta, id, locationId]);
      if (result.rows[0]) updated.push(result.rows[0]);
    }

    await client.query('COMMIT');
    client.release();
    res.json({ updated });

  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch {}
    client.release();
    next(err);
  }
});

/* ======================================================
   7️⃣ GLOBAL SEARCH (20k SKU modal)
   GET /search?q=milk
====================================================== */
router.get('/search', async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();

    const result = await db.query(
      `SELECT *
         FROM inventory
        WHERE item_name ILIKE $1
           OR barcode = $2
        ORDER BY item_name
        LIMIT 50`,
      [`%${q}%`, q]
    );

    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;